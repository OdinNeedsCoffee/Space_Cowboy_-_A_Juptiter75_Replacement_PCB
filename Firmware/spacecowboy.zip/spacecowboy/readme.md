# spacecowboy

![spacecowboy](https://imgur.com/a/1G6riW7)

Replacement PCB for the Jupiter75 keyboard made by _ODIN_ aka Odin_De

* Keyboard Maintainer: [_ODIN_](https://github.com/OdinNeedsCoffee)
* Hardware Supported: Space Cowboy rev1.2
* Hardware Availability: GB on Discord
                         Open source files on Github

Make example for this keyboard (after setting up your build environment):

    make spacecowboy:default

Flashing example for this keyboard:

    make spacecowboy:default:flash

See the [build environment setup](https://docs.qmk.fm/#/getting_started_build_tools) and the [make instructions](https://docs.qmk.fm/#/getting_started_make_guide) for more information. Brand new to QMK? Start with our [Complete Newbs Guide](https://docs.qmk.fm/#/newbs).
