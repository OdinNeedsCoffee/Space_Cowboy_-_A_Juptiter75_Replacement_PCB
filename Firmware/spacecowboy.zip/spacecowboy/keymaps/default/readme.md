# The default keymap for spacecowboy
